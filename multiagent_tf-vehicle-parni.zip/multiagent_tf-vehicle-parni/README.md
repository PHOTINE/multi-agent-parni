# Multi-Agent Goal-Driven Communication Environment

Implementation for the [Goal-Driven Communication](https://openai.quip.com/zMfIAOFifa8o) project.

## Getting started:

	# Run this first:
	pip install -r requirements.txt

    # To train policy for a flocking scenario (see others in ./scenarios/):
	bin/train.py --scenario scenarios/move_and_avoid.py

	# To evaluate policy and record rollouts to video:
	bin/evaluate.py --scenario scenarios/move_and_avoid.py

## Troubleshooting:

    On MacOS you need to have file ~/.matplotlib/matplotlibrc containing the following line "backend: TkAgg"
