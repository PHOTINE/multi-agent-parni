import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

import environment

from IPython.core.debugger import Tracer

class Renderer(object):
    def __init__(self):
        #plt.ion()
        plt.show()
        self.figure = plt.figure(figsize=(5,5))

    def finish(self):
        pass

    def start_frame(self):
        plt.clf()

    def stop_frame(self):
        plt.tight_layout()
        #plt.show()
        plt.draw()
        plt.pause(1e-5)

    def render_world(self, world, title, index = range(1)):
        # plt.subplot(122)


        # NOTETOSELF TODO better way to draw road
        # matplotlib.patches.Rectangle((0,0), 2, 2, angle=0.0, color=(0.1, 0.2, 0.5))
        # plt.scatter([-.5,0,.5], [-.5,0,.5], s=(0.050**2 * 1e+5  * np.pi), c="0", alpha=.4)

        # draw
        #  changed here

        plt.scatter([x for x in np.arange(-2,2,.01)], [0 for x in np.arange(-2,2,.01)], s=(0.15**2 * 1e+5  * np.pi), c='gray', alpha=1)
        plt.scatter([0 for x in np.arange(-2,2,.01)], [x for x in np.arange(-2,2,.01)], s=(0.15**2 * 1e+5  * np.pi), c='gray', alpha=1)
        # What is alpha does in this sencario?
        plt.scatter([x for x in np.arange(-2,2,.01)], [0 for x in np.arange(-2,2,.01)], s=(0.01**2 * 1e+5  * np.pi),c='yellow', alpha=1)
        plt.scatter([0 for x in np.arange(-2,2,.01)], [x for x in np.arange(-2,2,.01)], s=(0.01**2 * 1e+5  * np.pi),c='yellow', alpha=1)



        for agent in world.agents:
            # write nameplt.scatter([0 for x in np.arange(-2,2,.01)], [x for x in np.arange(-2,2,.01)], s=(0.15**2 * 1e+5  * np.pi), c='brown', alpha=1)

            plt.text(agent.init_state.x_pos[index,0], agent.init_state.x_pos[index,1] + agent.size, agent.name)
            # write communication message
            if not agent.silent:
                message = 'says: '
                com = agent.init_state.c[index[0],:]
                for i, v in enumerate(com):
                    message += ('%0.1f, ' % v)
                    #plt.scatter(agent.init_state.x_pos[index,0] + (2 + 1.0*i) * agent.size, agent.init_state.x_pos[index,1] - agent.size, s=(0.5*agent.size)**2 * 1e+5 * np.pi, marker='s', c='black', alpha=1.0)
                    #plt.scatter(agent.init_state.x_pos[index,0] + (2 + 1.0*i) * agent.size, agent.init_state.x_pos[index,1] - agent.size, s=(0.5*agent.size)**2 * 1e+5 * np.pi, marker='s', c='white', alpha=np.clip(v,0,1))
                #plt.text(agent.init_state.x_pos[index,0] + agent.size, agent.init_state.x_pos[index,1], message)
                plt.text(agent.init_state.x_pos[index,0] + agent.size, agent.init_state.x_pos[index,1] - agent.size, '%d' % com.argmax())
                # print agent.name + ' ' + message
            # write internal memory
            if True:
                message = 'thinks: '
                for i, v in enumerate(agent.init_state.m[index[0],:]):
                    message += ('%0.1f, ' % v)
                    #plt.scatter(agent.init_state.x_pos[index,0] + (2 + 1.0*i) * agent.size, agent.init_state.x_pos[index,1] + agent.size, s=(0.5*agent.size)**2 * 1e+5 * np.pi, marker='s', c='black', alpha=1.0)
                    #plt.scatter(agent.init_state.x_pos[index,0] + (2 + 1.0*i) * agent.size, agent.init_state.x_pos[index,1] + agent.size, s=(0.5*agent.size)**2 * 1e+5 * np.pi, marker='s', c='white', alpha=np.clip(v,0,1))
                #plt.text(agent.init_state.x_pos[index,0] + agent.size, agent.init_state.x_pos[index,1], message)
                #print agent.name + ' ' + message
            # TODO: use plt.Circle instead for corect size

            # NOTETOSELF
            plt.scatter(agent.init_state.x_pos[index,0], agent.init_state.x_pos[index,1], s=agent.size**2 * 1e+5 * np.pi/12, c=agent.color, alpha=0.25)
            # plt.scatter(agent.init_state.x_pos[index,0], agent.init_state.x_pos[index,1], s=agent.size**2 * 1e+5 * np.pi, c=agent.color, alpha=0.25) #edgecolors="yellow"


        for landmark in world.landmarks:
            # write name
            plt.text(landmark.init_state.x_pos[index,0], landmark.init_state.x_pos[index,1] + landmark.size, landmark.name)
            # TODO: use plt.Circle instead for corect size

            # NOTETOSELF
            plt.scatter(landmark.init_state.x_pos[index,0], landmark.init_state.x_pos[index,1], landmark.size**2 * 1e+5 * np.pi/12, c=landmark.color, alpha=0.50)
            # plt.scatter(landmark.init_state.x_pos[index,0], landmark.init_state.x_pos[index,1], landmark.size**2 * 1e+5 * np.pi, c=landmark.color, alpha=0.25) #edgecolors="yellow"
            #index change the landmark position but it does not effect the target. I want to see if we can set up landmark randomly random.rand.landmark.init_state.x_pos[index,1== here i want to indicate the range)
            #I want to make th circle smaller as well and change the coloring too
            # Assign the cost funcation
            # Add rules for propority of agents - for example, have unvisible line that agent can act only on that.
            # Add more rules for the position and volcity of the agent

        plt.xlim([-1.0,+1.0])
        plt.ylim([-1.0,+1.0])
        # hide axis labels
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_ticklabels([])
        cur_axes.axes.get_yaxis().set_ticklabels([])
        cur_axes.axes.set_title(title)

    def render_trajectory(self, world, agent_xpos, index = range(1)):
        # plt.subplot(122)
        for i, agent in enumerate(agent_xpos):
            xpos_prev = agent[0]
            for xpos in agent:
                segment = np.stack([xpos_prev, xpos])
                plt.plot(segment[:,index,0], segment[:,index,1], linewidth=1, color=(0.5,0.5,0.5, 1.0))
                xpos_prev = xpos
                #plt.scatter(xpos[I,0], xpos[I,1], s=world.agents[i].size**2 * 1e+5 * np.pi, c='red', alpha=0.05)

    def render_observation(self, world, agent_obs, index = range(1)):
        return
        # plt.subplot(122)
        for i, agent in enumerate(world.agents):
            obs = agent_obs[i]
            # plt.scatter(agent.init_state.x_pos[index,0], agent.init_state.x_pos[index,1], s=(0.030)**2 * 1e+5 * np.pi, c=obs.target_color, alpha=0.25)
            plt.scatter(agent.init_state.x_pos[index,0], agent.init_state.x_pos[index,1], s=(0.030)**2 * 1e+5 * np.pi, c=obs.target_color, alpha=0.8)

    def render_history(self, world, history_com, history_mem, T):
        # TODO: refactor to be general
        plt.subplot(421)
        plt.xlim([0,T])
        plt.ylim([0,1])#history_com[0].shape[1]-1])
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_ticklabels([])
        cur_axes.axes.get_yaxis().set_ticklabels([])
        cur_axes.axes.set_title(world.agents[0].name + ' message:')
        plt.plot(history_com[0]) #plt.imshow(history_com[0].T, vmin=-1.0, vmax=1.0) #
        plt.subplot(423)
        plt.xlim([0,T])
        plt.ylim([0,1])#history_com[1].shape[1]-1])
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_ticklabels([])
        cur_axes.axes.get_yaxis().set_ticklabels([])
        cur_axes.axes.set_title(world.agents[1].name + ' message:')
        plt.plot(history_com[1]) #plt.imshow(history_com[1].T, vmin=-1.0, vmax=1.0) #
        plt.subplot(425)
        plt.xlim([0,T])
        plt.ylim([-1,+1])#history_mem[0].shape[1]-1])
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_ticklabels([])
        cur_axes.axes.get_yaxis().set_ticklabels([])
        cur_axes.axes.set_title(world.agents[0].name + ' memory:')
        plt.plot(history_mem[0]) #plt.imshow(history_mem[0].T, vmin=-1.0, vmax=1.0)
        plt.subplot(427)
        plt.xlim([0,T])
        plt.ylim([-1,+1])#history_mem[1].shape[1]-1])
        cur_axes = plt.gca()
        cur_axes.axes.get_xaxis().set_ticklabels([])
        cur_axes.axes.get_yaxis().set_ticklabels([])
        cur_axes.axes.set_title(world.agents[1].name + ' memory:')
        plt.plot(history_mem[1]) #plt.imshow(history_mem[1].T, vmin=-1.0, vmax=1.0)
