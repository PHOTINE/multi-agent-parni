import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

import environment

from IPython.core.debugger import Tracer

# agent policy
class Policy(object):
    def __init__(self):
        self.created = False

    # construct policy input vector
    def make_input(self, agent, obs):
        return tf.concat(obs.agent_pos + obs.agent_vel + obs.landmark_pos + [obs.vel, obs.target_xpos],1)

    # create output network
    def make_output(self, agent, input):
        num_layer = 2
        dim_hidden = 64
        with tf.variable_scope("policy", reuse=self.created):
            seq = pt.wrap(input).sequential()
            for layer in xrange(num_layer):
                seq.fully_connected(dim_hidden, l2loss=1e-6, activation_fn=tf.nn.relu)
                #seq.dropout(0.95)
            output = seq.fully_connected(agent.dim_u + agent.dim_c + agent.dim_m, activation_fn=None).tensor
        self.created = True
        output_u = tf.reshape(output[:, :agent.dim_u], [-1, agent.dim_u])
        output_c = tf.reshape(output[:, agent.dim_u:(agent.dim_u+agent.dim_c)], [-1, agent.dim_c])
        output_m = tf.reshape(output[:, (agent.dim_u+agent.dim_c):], [-1, agent.dim_m])
        return [output_u, output_c, output_m]

    def evaluate(self, agent, obs):
        input = self.make_input(agent, obs)
        [output_u, output_c, output_m] = self.make_output(agent, input)
        # create action noise
        N = tf.shape(obs.vel)[0]
        noise_u = tf.reshape(tf.random_normal((N, agent.dim_u)) * agent.u_noise, [-1, agent.dim_u])
        #noise_c = tf.reshape(tf.random_normal((N, agent.dim_c)) * agent.c_noise, [-1, agent.dim_c])
        #noise_m = tf.reshape(tf.random_normal((N, agent.dim_m)) * agent.m_noise, [-1, agent.dim_m])
        # create action
        action = environment.Action()
        action.u = noise_u + output_u
        action.c = output_c# + noise_c
        action.m_vel = output_m# + noise_m
        return action
