import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

from IPython.core.debugger import Tracer

# create list of one hot activations (one per class)
def one_hot(batchsize, num_class, hot_index = None):
    if hot_index is None:
        hot_index = np.random.randint(0, num_class, batchsize)
    else:
        hot_index = np.ones(batchsize) * hot_index
    active = []
    for i in range(num_class):
        active.append((hot_index == i).astype(np.float32))
    return active

# select active elements from list specified by one-hot list
def select_one_hot(value, active):
    output = 0.0
    for i,v in enumerate(value):
        a = tf.reshape(active[i],[-1,1])
        output = output + a * v
    return output

# Disables write_meta_graph argument, which freezes entire process and is mostly useless.
class FastSaver(tf.train.Saver):
    def save(self, sess, save_path, global_step=None, latest_filename=None,
             meta_graph_suffix="meta", write_meta_graph=True):
        super(FastSaver, self).save(sess, save_path, global_step, latest_filename,
                                    meta_graph_suffix, False)
