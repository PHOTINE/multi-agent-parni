Python 3.6.1 (v3.6.1:69c0db5050, Mar 21 2017, 01:21:04)
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> WARNING: The version of Tcl/Tk (8.5.9) in use may be unstable.
Visit http://www.python.org/download/mac/tcltk/ for current information.
import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

import common

from IPython.core.debugger import Tracer

# state of the agent
class State(object):
    def __init__(self):
        # physical position
        self.x_pos = None
        # physical velocity
        self.x_vel = None
        # internal memory
        self.m = None
        # communication message
        self.c = None

# observation of the agent
class Observation(object):
    def __init__(self):
        # physical positions of all other agents relative to itself
        self.agent_pos = []
        # physical velocities of all other agents
        self.agent_vel = []
        # communication messages of all other agents
        self.agent_com = []
        # physical positions of all landmarks relative to itself
        self.landmark_pos = []
        # physical velocity
        self.vel = None
        # internal memory
        self.m = None
        # target location
        self.target_xpos = None

# goals of the agent
class Goal(object):
    def __init__(self):
        # cost preferences:
        # desire to approach target landmark
        self.w_approach = 1e-0
        # desire to approach main agent
        self.w_flock = 0.0
        # aversion to impact
        self.w_impact = 1e-0
        # physcal effort
        self.w_ueffort = 5e-3
        # communication effort
        self.w_ceffort = 1e-2
        # recurrent memory change effort
        self.w_meffort = 1e-4
        # one-hot activity vector for each landmark
        self.landmarks_target = []
        # agent to move to target
        self.target_agent = None

# action of the agent
class Action(object):
    def __init__(self):
        # physical action
        self.u = None
        # communication action
        self.c = None
        # internal memory change
        self.m_vel = None

# properties and dynamics of the agent
class Entity(object):
    def __init__(self):
        # name
        self.name = ''
        # dimensionality
        self.dim_x = 2
        self.dim_color = 3
        # properties
        self.size = None
        self.collider = None
        self.density = 50.0
        self.color = np.zeros(self.dim_color)
        # initial state
        self.init_state = State()


# properties and dynamics of the agent entity
class Agent(Entity):
    def __init__(self):
        super(Agent, self).__init__()
        # dimensionality
        self.dim_u = self.dim_x
        # TODO: expose these to be set by scenario
        self.dim_m = 10#64
        self.dim_c = 10
        # properties:
        self.size = 2.0
        # 0.050
        self.collider = True
        # cannot physically move
        self.passive = False
        # cannot send communication signals
        self.silent = False
        # cannot observe other landmarks
        self.blind_to_landmarks = False
        # cannot observe other agents
        self.blind_to_agents = False
        # physical motor noise
        self.u_noise = 0.0
        # communication output noise
        self.c_noise = 0.0
        # memory change noise
        self.m_noise = 0.0
        # goals of the agent
        self.goal = Goal()

# properties of the landmark entity
class Landmark(Entity):
     def __init__(self):
        super(Landmark, self).__init__()
        # properties
        self.size = 0.025
        self.collider = False

# multi-agent world
class World(object):
    def __init__(self):
        self.dt = 0.1
        self.damping = 0.75#0.5
        self.contact_force = 1e+2
        self.contact_margin = 1e-1 #1e-2
        self.c_temperature = 1.0 #2.0/3.0
        self.agents = []
        self.landmarks = []
        self.deltas = []

    def create_trajectory_graph(self, T, policy):
        # allocate constants
        self.c_temperature_node = tf.placeholder(tf.float32, 1)
        # allocate agents
        for agent in self.agents:
            # allocate time-varying trajectories
            agent.states = [None] * T
            agent.observations = [None] * (T-1)
            agent.actions = [None] * (T-1)
            agent.costs = [None] * (T-1)
            # create initial state
            agent.states[0] = State()
            agent.states[0].x_pos = tf.placeholder(tf.float32, [None, agent.dim_x])
            agent.states[0].x_vel = tf.placeholder(tf.float32, [None, agent.dim_x])
            agent.states[0].m = tf.placeholder(tf.float32, [None, agent.dim_m])
            agent.states[0].c = tf.placeholder(tf.float32, [None, agent.dim_c])
            agent.states[0].penetration = tf.zeros([tf.shape(agent.states[0].x_pos)[0],1])
            # create goal target
            agent.goal.landmarks_target_node = [tf.placeholder(tf.float32, [None]) for landmark in agent.goal.landmarks_target]
        # allocate landmarks
        for landmark in self.landmarks:
            # allocate a single time-invariant state
            landmark.state = State()
            landmark.state.x_pos = tf.placeholder(tf.float32, [None, landmark.dim_x])
        # create trajectory graph
        for t in xrange(T-1):
            for agent in self.agents:
                # construct observation
                agent.observations[t] = self.make_observation(agent, t)
                # get action from policy
                agent.actions[t] = policy(agent, agent.observations[t])
                # get next state
                agent.states[t+1] = self.make_next_state(agent, t)
                # construct reward
                agent.costs[t] = self.make_cost(agent, t)

    # construct observation for agent at time t
    def make_observation(self, agent, t):
        obs = Observation()
        obs.vel = agent.states[t].x_vel
        obs.m = agent.states[t].m
        # append agent observations
        for other in self.agents:
            if other is agent: continue
            if agent.blind_to_agents:
                obs.agent_pos.append(tf.zeros([tf.shape(other.states[t].x_pos)[0],other.dim_x]))
                obs.agent_vel.append(tf.zeros([tf.shape(other.states[t].x_vel)[0],other.dim_x]))
            else:
                obs.agent_pos.append(other.states[t].x_pos - agent.states[t].x_pos)
                obs.agent_vel.append(other.states[t].x_vel)
            # append communication
            obs.agent_com.append(other.states[t].c[:,1:])
        # append landmark observations
        for other in self.landmarks:
            if agent.blind_to_landmarks:
                obs.landmark_pos.append(tf.zeros([tf.shape(other.states[t].x_pos)[0],other.dim_x]))
            else:
                obs.landmark_pos.append(other.state.x_pos - agent.states[t].x_pos)
        # calculate target landmark position
        landmark_xpos = [landmark.state.x_pos for landmark in self.landmarks]
        landmark_target = agent.goal.landmarks_target_node
        obs.target_xpos = common.select_one_hot(landmark_xpos, landmark_target) - agent.states[t].x_pos
        return obs

    # construct reward
    def make_cost(self, agent, t):
        cost = 0.0
        target_agent = agent.goal.target_agent
        # calculate target landmark position
        landmark_xpos = [landmark.state.x_pos for landmark in self.landmarks]
        landmark_target = agent.goal.landmarks_target_node
        target_landmark_xpos = common.select_one_hot(landmark_xpos, landmark_target)
        # desire to approach target landmark
        cost = cost + agent.goal.w_approach * tf.reduce_mean(tf.reduce_sum(tf.square(target_agent.states[t].x_pos - target_landmark_xpos), 1))
        # desired to approach main agent
        cost = cost + agent.goal.w_flock * tf.reduce_mean(tf.reduce_sum(tf.square(agent.states[t].x_pos - self.agents[0].states[t].x_pos), 1))
        # aversion to impact
        cost = cost + agent.goal.w_impact * tf.reduce_mean(tf.reduce_sum(agent.states[t].penetration, 1))
        # physical effort
        cost = cost + agent.goal.w_ueffort * tf.reduce_mean(tf.reduce_sum(tf.square(agent.actions[t].u), 1))
        # memory change effort
        cost = cost + agent.goal.w_meffort * tf.reduce_mean(tf.reduce_sum(tf.square(agent.actions[t].m_vel), 1))
        # communication effort
        cost = cost + agent.goal.w_ceffort * tf.reduce_mean(tf.reduce_sum(tf.square(agent.states[t].c[:,1:]), 1))
        return cost


    # construct next state for agent
    def make_next_state(self, agent, t):
        state = State()
        # gather forces from the world
        if agent.passive:
            x_force = tf.zeros(tf.shape(agent.actions[t].u))
        else:
            x_force = agent.actions[t].u
        # collision response
        penetration = 0.0
        for other in self.agents:
            [x_force, penetration] = self.get_collision_acc(x_force, penetration, agent, agent.states[t], other, other.states[t])
        for other in self.landmarks:
            [x_force, penetration] = self.get_collision_acc(x_force, penetration, agent, agent.states[t], other, other.state)
        # cache state
        state.penetration = penetration
        # calculate mass
        mass = (4*np.pi*agent.size*agent.size) * agent.density
        x_acc = x_force# / mass
        # advance physical state
        state.x_vel = agent.states[t].x_vel * (1 - self.damping) + x_acc * self.dt
        state.x_pos = agent.states[t].x_pos + state.x_vel * self.dt
        # advance memory state
        noise_m = tf.reshape(tf.random_normal((tf.shape(agent.actions[t].m_vel)[0], agent.dim_m)) * agent.m_noise, [-1, agent.dim_m])
        state.m = agent.states[t].m + (agent.actions[t].m_vel + noise_m) * self.dt
        # set communication state
        if agent.silent:
            state.c = agent.actions[t].c * 0.0 #tf.zeros(tf.shape(agent.actions[t].c))
        else:
            noise_c = tf.reshape(tf.random_normal((tf.shape(agent.actions[t].c)[0], agent.dim_c)) * agent.c_noise, [-1, agent.dim_c])
            eps = 1e-10
            G = tf.reshape(tf.random_uniform((tf.shape(agent.actions[t].c)[0], agent.dim_c), 0.0 + eps, 1.0 - eps), [-1, agent.dim_c])
            G = -tf.log(-tf.log(G))
            state.c = tf.nn.softmax((agent.actions[t].c + G)/self.c_temperature_node)# + noise_c
            #state.c = tf.nn.softmax(agent.actions[t].c + noise_c)
            #state.c = agent.actions[t].c #agent.states[t].c * (1 - self.dt) + agent.actions[t].c * self.dt # #tf.nn.sigmoid(agent.actions[t].c) # communication utterances are in [0,1]
        return state

    # update acceleration applied to agent as a result of colliding with collider
    def get_collision_acc(self, x_acc, x_pen, entity_a, state_a, entity_b, state_b):
        if (not entity_a.collider) or (not entity_b.collider):
            return [x_acc, x_pen]
        if (entity_a is entity_b):
            return [x_acc, x_pen] # don't collide against itself
        # compute actual distance between entities
        delta_x_pos = state_a.x_pos - state_b.x_pos
        dist = tf.sqrt(tf.reduce_sum(tf.square(delta_x_pos), 1, keep_dims=True)) #tf.reduce_sum(tf.square(delta_x_pos), 1, keep_dims=True) #
        # minimum allowable distance
        dist_min = entity_a.size + entity_b.size #tf.square(entity_a.size + entity_b.size)
        # softmax penetration
        k = self.contact_margin
        penetration = tf.log(1 + tf.exp(-(dist - dist_min)/k))*k
        delta_x_acc = self.contact_force * delta_x_pos / dist * penetration
        return [x_acc + delta_x_acc, x_pen + penetration]

    def make_feed(self):
        feed = {}
        feed[self.c_temperature_node] = np.array([self.c_temperature])
        for agent in self.agents:
            feed[agent.states[0].x_pos] = agent.init_state.x_pos
            feed[agent.states[0].x_vel] = agent.init_state.x_vel
            feed[agent.states[0].m] = agent.init_state.m
            feed[agent.states[0].c] = agent.init_state.c
        for landmark in self.landmarks:
            feed[landmark.state.x_pos] = landmark.init_state.x_pos
        for agent in self.agents:
            for i in xrange(len(agent.goal.landmarks_target)):
                feed[agent.goal.landmarks_target_node[i]] = agent.goal.landmarks_target[i]
        return feed

    def optimize_parameters(self, session):
        opt, total_cost = session.run((self.optimizer, self.total_cost), self.make_feed())
        return total_cost

    def evaluate_agent_xpos(self, session):
        fetch = []
        for agent in self.agents:
            fetch = fetch + [state.x_pos for state in agent.states[1:]]
        output = session.run(fetch, self.make_feed())
        T = len(self.agents[0].states[1:])
        return [output[i:i + T] for i in xrange(0, len(output), T)]

    def evaluate_observation(self, session):
        fetch = []
        for agent in self.agents:
            fetch.append(agent.observations[0].vel)
            fetch.append(agent.observations[0].m)
            fetch.append(agent.observations[0].target_xpos)
        output = session.run(fetch, self.make_feed())
        # TODO: make this less ugly
        agent_observations = []
        i = 0
        for agent in self.agents:
            obs = Observation()
            obs.vel = output[i]
            i = i + 1
            obs.m = output[i]
            i = i + 1
            obs.target_xpos = output[i]
            i = i + 1
            agent_observations.append(obs)
        return agent_observations

    def evaluate_agent_next_state(self, session):
        fetch = []
        for agent in self.agents:
            fetch.append(agent.states[1].x_pos)
            fetch.append(agent.states[1].x_vel)
            fetch.append(agent.states[1].m)
            fetch.append(agent.states[1].c)
        output = session.run(fetch, self.make_feed())
        # TODO: make this less ugly
        agent_states = []
        i = 0
        for agent in self.agents:
            state = State()
            state.x_pos = output[i]
            i = i + 1
            state.x_vel = output[i]
            i = i + 1
            state.m = output[i]
            i = i + 1
            state.c = output[i]
            i = i + 1
            agent_states.append(state)
        return agent_states

class BaseScenario(object):
    # create training parameters
    def make_params(self, world):
        # set default parameters
        params = {}
        params["horizon"] = 25
        params["evaluation_horizon"] = 50
        params["evaluation_trials"] = 5
        params["learning_rate"] = 1e-2
        params["learning_iterations"] = 500
        params["snapshot_rate"] = 100
        # override from scenario
        return self.update_params(params, world)

    # create elements of the world
    def make_world(self, world):
        raise "not implemented"

    # create initial conditions of the world
    def make_world_initial_conditions(self, world):
        raise "not implemented"
