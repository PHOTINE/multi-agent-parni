import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle
import random

from source import common, environment, policy, renderer

from IPython.core.debugger import Tracer

class Scenario(environment.BaseScenario):
    # create elements of the world
    def make_world(self, world):
        # experiment parameters
        self.batchsize = 1024
        # add agents
        world.agents = [environment.Agent() for i in xrange(2)]
        for i, agent in enumerate(world.agents):
            agent.name = 'agent %d' % i
            agent.collider = True
            agent.u_noise = 1e-0
        # add landmarks
        world.landmarks = [environment.Landmark() for i in xrange(2)]
        for landmark in world.landmarks:
            # give different landmark colors
            landmark.color = np.random.rand(3)
            landmark.collider = False
        # make initial conditions
        self.make_world_initial_conditions(world)

    def make_world_initial_conditions(self, world):
        # set random initial states
        for i, agent in enumerate(world.agents):

            # NOTETOSELF changed starting position of agents to be constant.
            #uncomment code in "place agent randomly on a circle" paragraph to reinstate randomness

            # added  np.pi/20 to make start on right side of road, roughly
            # angle = [ np.pi/2*random.randint(0,4)for x in range (self.batchsize)]

            angle = [random.randint(0, 4) * np.pi/2 for i in range(self.batchsize)]

                ###  * i + np.pi/20

            # angle= np.random.uniform (np.pi/2, np.pi/20, self.batchsize)

            # place agent randomly on a circle
            #angle = np.random.uniform(-np.pi,+np.pi, self.batchsize)
            # Tracer()()

            # radius on which to place agent randomly
            radius = 0.9

                # def sample_x_pos(self, batchsize, dim_x):
                #     X_pos = [ np.empty([batchsize, dim_x]) for i in range(4)]
                #     X_pos[0] = [-1,0]
                #     X_pos[1] = [+1,0]
                #     X_pos[2] = [0,-1]
                #     X_pos[3] = [0,+1]
                #     mask = one_hot(batchsize, 4)
                #     x_pos = select_one_hot(X_pos, mask)
                #     return x_pos

            agent.init_state.x_pos = radius * np.stack([np.cos(angle), np.sin(angle)], axis=1)
            agent.init_state.x_vel = np.zeros([self.batchsize, agent.dim_x])

            agent.init_state.m = np.zeros([self.batchsize, agent.dim_m])
            agent.init_state.c = np.zeros([self.batchsize, agent.dim_c])

            # set random target goal landmarks

            agent.goal.landmarks_target = common.one_hot(self.batchsize, len(world.landmarks), hot_index = i)

            # Tracer()()

            # agent is the one that needs to get to landmark
            agent.goal.target_agent = agent

        # add landmarks
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' % i
            # place landmark opposite of the agent


            landmark.init_state.x_pos = -world.agents[(i+1)%2].init_state.x_pos

    # create training parameters
    def update_params(self, params, world):
        params["horizon"] = 25
        params["evaluation_trials"] = 10
        params["evaluation_horizon"] = 25
        params["learning_rate"] = 1e-2
        params["learning_iterations"] = 1000
        params["snapshot_rate"] = 250
        return params
