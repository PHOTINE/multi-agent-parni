import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

from source import common, environment, policy, renderer

from IPython.core.debugger import Tracer

class Scenario(environment.BaseScenario):
    # create elements of the world
    def make_world(self, world):
        # experiment parameters
        self.batchsize = 1024
        # add agents
        world.agents = [environment.Agent() for i in xrange(3)]
        # give agents different sizes just for fun
        world.agents[0].size = 0.075
        world.agents[1].size = 0.050
        world.agents[2].size = 0.040
        for i, agent in enumerate(world.agents):
            agent.name = 'agent %d' % i
            agent.collider = False
        # add landmarks
        world.landmarks = [environment.Landmark() for i in xrange(3)]
        for landmark in world.landmarks:
            # give different landmark colors
            landmark.color = np.random.rand(3)          
        # make initial conditions
        self.make_world_initial_conditions(world)

    def make_world_initial_conditions(self, world):            
        # set random initial states
        for agent in world.agents:
            agent.init_state.x_pos = np.random.uniform(-1,+1, [self.batchsize, agent.dim_x])
            agent.init_state.x_vel = np.zeros([self.batchsize, agent.dim_x])
            agent.init_state.m = np.zeros([self.batchsize, agent.dim_m])
            agent.init_state.c = np.zeros([self.batchsize, agent.dim_c])
            # set random target goal landmarks
            agent.goal.landmarks_target = common.one_hot(self.batchsize, len(world.landmarks))
            # agent is the one that needs to get to landmark
            agent.goal.target_agent = agent                

        # add landmarks            
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' % i
            landmark.init_state.x_pos = np.random.uniform(-1,+1, [self.batchsize, landmark.dim_x])
            
    # create training parameters
    def update_params(self, params, world):
        params["horizon"] = 25
        params["evaluation_trials"] = 5
        params["evaluation_horizon"] = 50
        params["learning_rate"] = 1e-2
        params["learning_iterations"] = 5000
        params["snapshot_rate"] = 500
        return params
