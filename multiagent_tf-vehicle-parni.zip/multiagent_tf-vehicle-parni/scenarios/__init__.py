import imp

def load(name):
    return imp.load_source('', name)