import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

from source import common, environment, policy, renderer

from IPython.core.debugger import Tracer

class Scenario(environment.BaseScenario):
    # create elements of the world
    def make_world(self, world):
        # experiment parameters
        self.batchsize = 1024
        # add agents
        world.agents = [environment.Agent() for i in xrange(2)]
        for i, agent in enumerate(world.agents):
            agent.name = 'agent %d' % i
            agent.collider = False
            agent.u_noise = 1e-1
            agent.m_noise = 1e-1
            agent.c_noise = 1e-1
        # add landmarks
        world.landmarks = [environment.Landmark() for i in xrange(3)]
        world.landmarks[0].color = np.array([1.0, 0.0, 0.0])
        world.landmarks[1].color = np.array([0.0, 1.0, 0.0])
        world.landmarks[2].color = np.array([0.0, 0.0, 1.0])
        # make initial conditions
        self.make_world_initial_conditions(world)

    # def sample_x_pos(self, batchsize, dim_x):
    #     X_pos = [ np.empty([batchsize, dim_x]) for i in range(4)]
    #     X_pos[0] = [-1,0]
    #     X_pos[1] = [+1,0]
    #     X_pos[2] = [0,-1]
    #     X_pos[3] = [0,+1]
    #     mask = one_hot(batchsize, 4)
    #     x_pos = select_one_hot(X_pos, mask)
    #     return x_pos
    # def sample_x_pos(self, batchsize, dim_x):
    #     x_pos= np.empty([4, dim_x])
    #     x_pos[0] = [-1,0]
    #     x_pos[1] = [+1,0]
    #     x_pos[2] = [0,-1]
    #     x_pos[3] = [0,+1]
    #     daniel= np.random.randint(4, size=batchsize)
    #     return x_pos[daniel,:]

    def make_world_initial_conditions(self, world, hot_index = None):
        # set random initial states
        for agent_index, agent in enumerate(world.agents):
            agent.init_state.x_pos = np.random.uniform(-1,+1, [self.batchsize, agent.dim_x])
            #agent.init_state.x_pos = self.sample_x_pos(self.batchsize,agent.dim_x)
                # I do not understand what is -1,+1 indicate?
            agent.init_state.x_vel = np.zeros([self.batchsize, agent.dim_x])
            agent.init_state.m = np.zeros([self.batchsize, agent.dim_m])
            agent.init_state.c = np.zeros([self.batchsize, agent.dim_c])
            # set random target goal landmarks
            agent.goal.landmarks_target = common.one_hot(self.batchsize, len(world.landmarks))
            # make the target agent be neighboring agent
            agent.goal.target_agent = world.agents[(agent_index + 1) % len(world.agents)]

        # add landmarks
        for i, landmark in enumerate(world.landmarks):
            landmark.name = 'landmark %d' % i
            landmark.init_state.x_pos = np.random.uniform(-1,+1, [self.batchsize, landmark.dim_x])
            #landmark.init_state.x_pos = self.sample_x_pos(self.batchsize,landmark.dim_x)
    # create training parameters
    def update_params(self, params, world):
        params["horizon"] = 25
        params["evaluation_trials"] = 10
        params["evaluation_horizon"] = 25
        params["learning_rate"] = 1e-2
        params["learning_iterations"] = 5000
        params["snapshot_rate"] = 250
        return params
