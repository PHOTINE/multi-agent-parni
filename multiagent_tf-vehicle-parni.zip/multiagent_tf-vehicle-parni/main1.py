
import click
import sys
import os
import numpy as np
import tensorflow as tf
import prettytensor as pt
import cPickle as pickle

sys.path.insert(1, os.path.join(sys.path[0], '..'))

from source import common, environment, policy
import scenarios

from IPython.core.debugger import Tracer

def train(scenario_name, policy_path):
    seed = 0
    # load scenario from script
    scenario = scenarios.load(scenario_name).Scenario()
    # set randomness seeds
    np.random.seed(seed)
    tf.set_random_seed(seed)
    # create policy
    pol = policy.Policy()
    # create world
    world = environment.World()
    # construct world from scenario
    scenario.make_world(world)
    # construct parameters from scenario
    params = scenario.make_params(world)
    # create trajectory graph
    world.create_trajectory_graph(params["horizon"], pol.evaluate)
    # create co-operative loss
    total_cost = 0.0
    total = 0
    for agent in world.agents:
        for cost in agent.costs:
            total_cost = total_cost + cost
            total = total + 1
    world.total_cost = total_cost / total
    # create optimizer
    if params["learning_iterations"] > 0:
        world.optimizer = tf.train.AdamOptimizer(learning_rate=params["learning_rate"]).minimize(world.total_cost)
    # initialize tensorflow
    session = tf.Session()
    session.run(tf.initialize_all_variables())
    # create saver
    saver = common.FastSaver(tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES))
    tf.get_default_graph().finalize()    
    # optimize policy
    for iteration in xrange(1,params["learning_iterations"]+1):
        # create new initial conditions for trial
        np.random.seed(seed + iteration)
        tf.set_random_seed(seed + iteration)        
        scenario.make_world_initial_conditions(world)
        # optimize policy
        loss = world.optimize_parameters(session)
        print "iteration: %d loss: %0.5e" % (iteration,loss)
        # save the network snapshot
        if iteration % params["snapshot_rate"] == 0:
            print "saving snapshot to %s" % policy_path
            saver.save(session, policy_path)
    saver.save(session, policy_path)

@click.command()
@click.option('--scenario', type=str, default='', help='name of scenario script')
@click.option('--policy_path', type=str, default='/tmp/policy.pkl', help='filename of the policy')
def main(scenario, policy_path):
    train(scenario, policy_path)

if __name__ == '__main__':
    main()
